<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="style.css" />
        <title>SaisieCours</title>
    </head>

    <body>
    <?php
    print_r($_FILES["userfile"]);
    print_r($_FILES["userfile"]["tmp_name"]); 
    ?>
    </body>
</html>